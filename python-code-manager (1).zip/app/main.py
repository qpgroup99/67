from __future__ import annotations

import hashlib
import os
import secrets
import shutil
import tempfile
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Generator

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from passlib.context import CryptContext
from dotenv import load_dotenv
from sqlalchemy import Boolean, DateTime, Integer, String, Text, create_engine, or_, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker
from starlette.middleware.sessions import SessionMiddleware

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", str(BASE_DIR / "uploads")))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR / 'python_tools.db'}")
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "10")) * 1024 * 1024
SECRET_KEY = os.getenv("APP_SECRET_KEY", "dev-only-change-this-secret")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin")
RUNNER_ENABLED = os.getenv("RUNNER_ENABLED", "false").lower() == "true"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

class Base(DeclarativeBase):
    pass

class Tool(Base):
    __tablename__ = "tools"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(160))
    slug: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(80), default="عام")
    libraries: Mapped[str] = mapped_column(String(500), default="")
    install_command: Mapped[str] = mapped_column(String(500), default="")
    run_command: Mapped[str] = mapped_column(String(500), default="")
    code: Mapped[str] = mapped_column(Text, default="")
    original_filename: Mapped[str | None] = mapped_column(String(255), nullable=True)
    stored_filename: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_published: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(engine)

app = FastAPI(title="Python Tools Manager")
from fastapi.staticfiles import StaticFiles
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY, session_cookie="pytools_session", max_age=60 * 60 * 8, same_site="lax", https_only=False)


def db() -> Generator[Session, None, None]:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def is_admin(request: Request) -> bool:
    return bool(request.session.get("admin"))


def require_admin(request: Request) -> None:
    if not is_admin(request):
        raise HTTPException(status_code=303, headers={"Location": "/admin/login"})


def csrf_token(request: Request) -> str:
    token = request.session.get("csrf")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf"] = token
    return token


def check_csrf(request: Request, token: str) -> None:
    expected = request.session.get("csrf")
    if not expected or not secrets.compare_digest(expected, token):
        raise HTTPException(status_code=400, detail="رمز حماية الطلب غير صالح")


def slugify(value: str) -> str:
    safe = "".join(ch.lower() if ch.isalnum() else "-" for ch in value).strip("-")
    return safe[:160] or secrets.token_hex(8)


def unique_slug(session: Session, title: str, current_id: int | None = None) -> str:
    base = slugify(title)
    candidate, index = base, 2
    while True:
        query = select(Tool).where(Tool.slug == candidate)
        if current_id:
            query = query.where(Tool.id != current_id)
        if not session.scalar(query):
            return candidate
        candidate, index = f"{base}-{index}", index + 1


def view_context(request: Request, **kwargs):
    return {"request": request, "is_admin": is_admin(request), "csrf": csrf_token(request), **kwargs}

@app.get("/", response_class=HTMLResponse)
def home(request: Request, q: str = "", category: str = "", session: Session = Depends(db)):
    stmt = select(Tool).where(Tool.is_published.is_(True)).order_by(Tool.updated_at.desc())
    if q:
        needle = f"%{q}%"
        stmt = stmt.where(or_(Tool.title.ilike(needle), Tool.description.ilike(needle), Tool.libraries.ilike(needle)))
    if category:
        stmt = stmt.where(Tool.category == category)
    tools = session.scalars(stmt).all()
    categories = session.scalars(select(Tool.category).where(Tool.is_published.is_(True)).distinct()).all()
    return templates.TemplateResponse("home.html", view_context(request, tools=tools, categories=categories, q=q, category=category))

@app.get("/tool/{slug}", response_class=HTMLResponse)
def tool_detail(slug: str, request: Request, session: Session = Depends(db)):
    tool = session.scalar(select(Tool).where(Tool.slug == slug, Tool.is_published.is_(True)))
    if not tool:
        raise HTTPException(404, "الأداة غير موجودة")
    return templates.TemplateResponse("tool.html", view_context(request, tool=tool))

@app.get("/admin/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", view_context(request, error=None))

@app.post("/admin/login")
def login(request: Request, password: str = Form(...), csrf: str = Form(...)):
    check_csrf(request, csrf)
    if secrets.compare_digest(password, ADMIN_PASSWORD):
        request.session["admin"] = True
        return RedirectResponse("/admin", status_code=303)
    return templates.TemplateResponse("login.html", view_context(request, error="كلمة المرور غير صحيحة"), status_code=401)

@app.post("/admin/logout")
def logout(request: Request, csrf: str = Form(...)):
    check_csrf(request, csrf)
    request.session.clear()
    return RedirectResponse("/", status_code=303)

@app.get("/admin", response_class=HTMLResponse)
def admin_dashboard(request: Request, q: str = "", session: Session = Depends(db)):
    require_admin(request)
    stmt = select(Tool).order_by(Tool.updated_at.desc())
    if q:
        stmt = stmt.where(or_(Tool.title.ilike(f"%{q}%"), Tool.libraries.ilike(f"%{q}%")))
    tools = session.scalars(stmt).all()
    return templates.TemplateResponse("admin.html", view_context(request, tools=tools, q=q))

@app.get("/admin/tools/new", response_class=HTMLResponse)
def new_tool_page(request: Request):
    require_admin(request)
    return templates.TemplateResponse("tool_form.html", view_context(request, tool=None, error=None))

@app.get("/admin/tools/{tool_id}/edit", response_class=HTMLResponse)
def edit_tool_page(tool_id: int, request: Request, session: Session = Depends(db)):
    require_admin(request)
    tool = session.get(Tool, tool_id)
    if not tool:
        raise HTTPException(404, "الأداة غير موجودة")
    return templates.TemplateResponse("tool_form.html", view_context(request, tool=tool, error=None))

@app.post("/admin/tools/save")
async def save_tool(request: Request, title: str = Form(...), description: str = Form(""), category: str = Form("عام"), libraries: str = Form(""), install_command: str = Form(""), run_command: str = Form(""), code: str = Form(""), tool_id: str = Form(""), csrf: str = Form(...), upload: UploadFile | None = File(None), session: Session = Depends(db)):
    require_admin(request)
    check_csrf(request, csrf)
    if len(title.strip()) < 2:
        raise HTTPException(400, "اسم الأداة قصير جدًا")
    tool = session.get(Tool, int(tool_id)) if tool_id else Tool()
    if tool_id and not tool:
        raise HTTPException(404, "الأداة غير موجودة")
    tool.title, tool.slug = title.strip(), unique_slug(session, title, tool.id if tool.id else None)
    tool.description, tool.category = description.strip(), category.strip()[:80] or "عام"
    tool.libraries, tool.install_command, tool.run_command, tool.code = libraries.strip(), install_command.strip(), run_command.strip(), code
    if upload and upload.filename:
        filename = Path(upload.filename).name
        suffix = Path(filename).suffix.lower()
        if suffix not in {".py", ".zip"}:
            raise HTTPException(400, "يسمح فقط بملفات .py أو .zip")
        content = await upload.read(MAX_UPLOAD_BYTES + 1)
        if len(content) > MAX_UPLOAD_BYTES:
            raise HTTPException(413, "حجم الملف أكبر من الحد المسموح")
        stored = f"{secrets.token_hex(16)}{suffix}"
        (UPLOAD_DIR / stored).write_bytes(content)
        if tool.stored_filename:
            (UPLOAD_DIR / tool.stored_filename).unlink(missing_ok=True)
        tool.original_filename, tool.stored_filename = filename, stored
        if suffix == ".py" and not code:
            tool.code = content.decode("utf-8", errors="replace")
    if not tool.id:
        session.add(tool)
    session.commit()
    return RedirectResponse("/admin", status_code=303)

@app.post("/admin/tools/{tool_id}/toggle")
def toggle_tool(tool_id: int, request: Request, csrf: str = Form(...), session: Session = Depends(db)):
    require_admin(request)
    check_csrf(request, csrf)
    tool = session.get(Tool, tool_id)
    if not tool:
        raise HTTPException(404, "الأداة غير موجودة")
    tool.is_published = not tool.is_published
    session.commit()
    return RedirectResponse("/admin", status_code=303)

@app.post("/admin/tools/{tool_id}/delete")
def delete_tool(tool_id: int, request: Request, csrf: str = Form(...), session: Session = Depends(db)):
    require_admin(request)
    check_csrf(request, csrf)
    tool = session.get(Tool, tool_id)
    if not tool:
        raise HTTPException(404, "الأداة غير موجودة")
    if tool.stored_filename:
        (UPLOAD_DIR / tool.stored_filename).unlink(missing_ok=True)
    session.delete(tool)
    session.commit()
    return RedirectResponse("/admin", status_code=303)

@app.get("/download/{tool_id}")
def download_tool(tool_id: int, request: Request, session: Session = Depends(db)):
    require_admin(request)
    tool = session.get(Tool, tool_id)
    if not tool or not tool.is_published or not tool.stored_filename:
        raise HTTPException(404, "الملف غير موجود")
    path = (UPLOAD_DIR / tool.stored_filename).resolve()
    if path.parent != UPLOAD_DIR.resolve() or not path.is_file():
        raise HTTPException(404, "الملف غير موجود")
    return StreamingResponse(open(path, "rb"), media_type="application/octet-stream", headers={"Content-Disposition": f'attachment; filename="{tool.original_filename or tool.stored_filename}"'})

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "python-tools-manager"}

@app.get("/api/tools")
def mobile_tools(session: Session = Depends(db)):
    """Public mobile catalog. Deliberately excludes code, stored filenames and secrets."""
    tools = session.scalars(select(Tool).where(Tool.is_published.is_(True)).order_by(Tool.updated_at.desc())).all()
    return [{"id": t.id, "title": t.title, "slug": t.slug, "description": t.description,
             "category": t.category, "libraries": [x.strip() for x in t.libraries.split(",") if x.strip()],
             "has_file": bool(t.stored_filename)} for t in tools]

@app.get("/api/tools/{tool_id}")
def mobile_tool(tool_id: int, session: Session = Depends(db)):
    tool = session.scalar(select(Tool).where(Tool.id == tool_id, Tool.is_published.is_(True)))
    if not tool:
        raise HTTPException(404, "الأداة غير موجودة")
    return {"id": tool.id, "title": tool.title, "description": tool.description,
            "category": tool.category, "libraries": [x.strip() for x in tool.libraries.split(",") if x.strip()],
            "install_command": tool.install_command, "run_command": tool.run_command,
            "can_run": RUNNER_ENABLED}

@app.post("/api/tools/{tool_id}/run")
def run_mobile_tool(tool_id: int, session: Session = Depends(db)):
    """Runner is intentionally disabled until an isolated container runner is configured."""
    tool = session.scalar(select(Tool).where(Tool.id == tool_id, Tool.is_published.is_(True)))
    if not tool:
        raise HTTPException(404, "الأداة غير موجودة")
    if not RUNNER_ENABLED:
        return {"status": "disabled", "message": "التشغيل غير مفعّل بعد. اربط Sandbox معزول قبل تفعيله."}
    return {"status": "queued", "message": "تم وضع الأداة في قائمة التشغيل الآمن", "tool_id": tool.id}
