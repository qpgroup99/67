import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8000');

class Tool {
  final int id; final String title, description, category; final List<String> libraries;
  Tool({required this.id, required this.title, required this.description, required this.category, required this.libraries});
  factory Tool.fromJson(Map<String, dynamic> j) => Tool(id: j['id'], title: j['title'] ?? '', description: j['description'] ?? '', category: j['category'] ?? 'عام', libraries: List<String>.from(j['libraries'] ?? []));
}

void main() => runApp(const PyForgeApp());

class PyForgeApp extends StatelessWidget { const PyForgeApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner: false, title: 'PyForge', theme: ThemeData.dark(useMaterial3: true).copyWith(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff55e1ce), brightness: Brightness.dark), scaffoldBackgroundColor: const Color(0xff08111f)), home: const CatalogPage());
}

class CatalogPage extends StatefulWidget { const CatalogPage({super.key}); @override State<CatalogPage> createState() => _CatalogPageState(); }
class _CatalogPageState extends State<CatalogPage> {
  late Future<List<Tool>> future;
  @override void initState() { super.initState(); future = loadTools(); }
  Future<List<Tool>> loadTools() async { final r = await http.get(Uri.parse('$apiBaseUrl/api/tools')); if (r.statusCode != 200) throw Exception('تعذر الاتصال بالخادم'); return (jsonDecode(r.body) as List).map((x) => Tool.fromJson(x)).toList(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('PyForge', style: TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(onPressed: () => setState(() => future = loadTools()), icon: const Icon(Icons.refresh))]), body: FutureBuilder<List<Tool>>(future: future, builder: (context, snap) { if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator()); if (snap.hasError) return Center(child: Text('${snap.error}')); final tools = snap.data ?? []; if (tools.isEmpty) return const Center(child: Text('لا توجد أدوات منشورة بعد')); return RefreshIndicator(onRefresh: () async => setState(() => future = loadTools()), child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: tools.length, itemBuilder: (_, i) => ToolCard(tool: tools[i]))); }));
}

class ToolCard extends StatelessWidget { final Tool tool; const ToolCard({super.key, required this.tool});
  @override Widget build(BuildContext context) => Card(color: const Color(0xff10223a), margin: const EdgeInsets.only(bottom: 14), child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ToolPage(tool: tool))), child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tool.category, style: const TextStyle(color: Color(0xff55e1ce), fontSize: 12)), const SizedBox(height: 8), Text(tool.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(tool.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70)), const SizedBox(height: 12), Wrap(spacing: 6, children: tool.libraries.map((x) => Chip(label: Text(x, style: const TextStyle(fontSize: 11)), padding: EdgeInsets.zero)).toList()), const Align(alignment: Alignment.centerLeft, child: Icon(Icons.arrow_back, color: Color(0xff67b7ff))) ]))));
}

class ToolPage extends StatefulWidget { final Tool tool; const ToolPage({super.key, required this.tool}); @override State<ToolPage> createState() => _ToolPageState(); }
class _ToolPageState extends State<ToolPage> { bool loading = false; String? result;
  Future<void> run() async { setState(() { loading = true; result = null; }); try { final r = await http.post(Uri.parse('$apiBaseUrl/api/tools/${widget.tool.id}/run')); final j = jsonDecode(r.body); setState(() => result = j['message'] ?? 'تم إرسال الطلب'); } catch (_) { setState(() => result = 'تعذر الاتصال بالخادم'); } finally { setState(() => loading = false); } }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.tool.title)), body: ListView(padding: const EdgeInsets.all(20), children: [Text(widget.tool.category, style: const TextStyle(color: Color(0xff55e1ce))), const SizedBox(height: 12), Text(widget.tool.title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 12), Text(widget.tool.description, style: const TextStyle(color: Colors.white70, height: 1.7)), const SizedBox(height: 25), const Text('المكتبات', style: TextStyle(fontWeight: FontWeight.bold)), Wrap(spacing: 6, children: widget.tool.libraries.map((x) => Chip(label: Text(x))).toList()), const SizedBox(height: 30), FilledButton.icon(onPressed: loading ? null : run, icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow), label: Text(loading ? 'جارٍ الإرسال...' : 'تشغيل الأداة')), const SizedBox(height: 10), OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back), label: const Text('رجوع')), if (result != null) Padding(padding: const EdgeInsets.only(top: 20), child: Card(color: const Color(0xff3b2d19), child: Padding(padding: const EdgeInsets.all(14), child: Text(result!)))) ]));
}
