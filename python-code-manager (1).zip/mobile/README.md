# PyForge Mobile

تطبيق Flutter للمستخدمين فقط. يعرض الأدوات المنشورة من FastAPI ولا يستلم أي كود Python.

## التشغيل المحلي

```bash
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000
```

لجهاز حقيقي استبدل العنوان بعنوان الخادم على الشبكة أو رابط HTTPS:

```bash
flutter build apk --release --dart-define=API_BASE_URL=https://your-domain.example
```

ناتج APK سيكون عادة في `build/app/outputs/flutter-apk/app-release.apk`.

> زر التشغيل يستدعي API فقط. الخادم مضبوط افتراضيًا على تعطيل تنفيذ الأكواد حتى يتم إعداد Sandbox معزول؛ هذا يمنع تشغيل ملف Python مرفوع مباشرة على خادم التطبيق.
