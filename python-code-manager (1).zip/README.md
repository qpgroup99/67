# Python Tools Manager

تطبيق FastAPI + SQLite لإدارة ونشر أكواد وملفات Python.

## المزايا
- تسجيل دخول للأدمن بجلسة مشفرة.
- كلمة المرور الأولية `admin` للتجربة فقط؛ غيّرها في `.env` قبل أي نشر.
- إضافة وتعديل وحذف ونشر/إخفاء الأدوات.
- رفع ملفات `.py` و`.zip` مع حد للحجم.
- بحث وتصفية حسب التصنيف والمكتبات.
- عرض الكود ونسخه وتنزيل الملفات.
- لا يشغّل أي كود مرفوع على الخادم.

## التشغيل

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# عدّل APP_SECRET_KEY و ADMIN_PASSWORD في .env
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

ثم افتح: http://127.0.0.1:8000

## النشر الآمن
- استخدم HTTPS وغيّر `ADMIN_PASSWORD` و`APP_SECRET_KEY`.
- لا تضع Bot Token أو API ID/API Hash داخل كود عام.
- شغّل التطبيق خلف reverse proxy ومستخدم نظام محدود الصلاحيات.
- افحص الملفات قبل نشرها، ولا تضف ميزة تشغيل الأكواد إلا داخل Sandbox معزول.
